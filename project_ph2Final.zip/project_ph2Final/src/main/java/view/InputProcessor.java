package view;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Objects;
import java.util.Scanner;

import static java.sql.DriverManager.getConnection;

public class InputProcessor {
    private Scanner scanner = new Scanner(System.in);
    private controller.Manager manager;
    ArrayList<String> a = new ArrayList<>();

    public InputProcessor(controller.Manager manager) {
        this.manager = manager;
    }

    private void processCreateAccounts(String username) throws IOException, SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {

        String input="";
        while (!input.startsWith("asjfdkhhdjfsa")) {
            System.out.println("chose account type");
            System.out.println("1: normal Account");
            System.out.println("2: business Account");
            input = scanner.nextLine();
            if (input.equalsIgnoreCase("1")) {
                modle.NormalAccount.processCreateNormalAccounts(username);
                return;
            } else if (input.equalsIgnoreCase("2")) {
                modle. BusinessAccount.processCreateBusinessAccounts(username);
                return;
            }
        }
    }

    public void run() throws IOException, SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {

        String input = "";
        System.out.println("THE Main is Running ...");
        while (input != "exit") {
            System.out.println(" \nEnter one of  Signup - login - forgetPassword - exit \n ");
            input = scanner.nextLine();
            input = input.toLowerCase();

            if (input.startsWith("login")) {
                System.out.println("Please Enter Your Username ... ");
                String username = scanner.nextLine();
                System.out.println("Please Enter Your Password ... ");
                String password = scanner.nextLine();
                String rr = username + "-" + password;
                modle.Login.loginuser(rr);
            }

            if (input.startsWith("signup")) {
                System.out.println("Please Enter Username ... ");
                String username = "";
                username = scanner.nextLine();
                boolean userbool = false;
                while (!userbool) {
                    userbool = modle.Signup.findUser(username);
                    if (userbool == false)
                        username = scanner.nextLine();
                }
                //String password = modle.UserInfo.makepassword();
               // modle.Signup.makeUser(username, password);

                processCreateAccounts(username);
            }
            if (input.startsWith("forgetPassword")) {
                System.out.println("What is your username ?");
                String username = scanner.nextLine();
               // modle.ForgetPassword.resetPassword(username);
            }
            input = "";
        }
        while (!(input = scanner.nextLine()).equalsIgnoreCase("exit")) {
            if (input.equalsIgnoreCase("create account")) {
                //   processCreateAccounts();
            }
        }
    }

    public static void tweetRun(String username) {
        String input = "";
        while (input != "exit") {
            Scanner scanner = new Scanner(System.in);
            System.out.println("\n Enter one of SendTweet-DeleteTweet-exit\n");
            input = scanner.nextLine();
            input = input.toLowerCase();
            if (input.startsWith("exit"))
                return;
            if (input.startsWith("sendtweet")) {
             //   modle. tweet.sendTweet(username);
            }
            if (input.startsWith("deletetweet")) {
                System.out.println("what is the number of tweet ? ");
                int number = scanner.nextInt();
                modle. tweet.deletTweet(username, number);
            }
        }
    }

      public static String Likerun(String username, int tweet_number) {
        String table_name = modle.comment.FindTableName(username, tweet_number);
        return table_name ;
    }

    public static void privateChat(String username) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
        Connection  conn = getConnection(url);
        Scanner scanner = new Scanner(System.in);
        String input = "";
        System.out.println("Enter the username you want to chat with (him,her) :");
        String username2 = scanner.nextLine();
        while (!tableExist(username2)){
            System.out.println(" username dosent exist enter username with is exist:");
            username2 = scanner.nextLine();
        }

        if (modle.Block.checkBlock(username2,username)){
                System.out.println("you blocked can't send message");
                return;
            }

        int a= username.compareTo(username2);
        String nameChat;
        if(a>0){
            nameChat="privateChat_"+username+"_"+username2;
        }
        else {
            nameChat="privateChat_"+username2+"_"+username;
        }
        nameChat=nameChat.toLowerCase(Locale.ROOT);


        String privateChatText = "";
        if(!tableExist(nameChat)){
            System.out.println("Enter the text you want to send user :");
            privateChatText = scanner.nextLine();
          // start chat
            modle. PrivateChat.startPrivateChat(username, username2, privateChatText);
            //continue chat

            System.out.println("if you want finish chat write exit");
            System.out.println("Enter the text you want to send user :");
            modle. PrivateChat.ShowChat(username,username2);
            privateChatText = scanner.nextLine();
            while (!Objects.equals(privateChatText, "exit")) {
                modle. PrivateChat.privateChat( username, username2, privateChatText);
                privateChatText = scanner.nextLine();
            }
        }
        else {//continue chat
            modle. PrivateChat.ShowChat(username,username2);
            System.out.println("Enter one of send message-reply-forward-edit-delete-exit");
            privateChatText = scanner.nextLine();
            while (!Objects.equals(privateChatText, "exit")) {

                String Text="";
                    if (Objects.equals(privateChatText, "send message")) {
                        System.out.println("Enter the text you want to send user : -exit");
                        Text=scanner.nextLine();
                        while (!Objects.equals(Text, "exit")) {
                        System.out.println("Enter the text you want to send user : -exit");
                            modle.  PrivateChat.privateChat(username, username2,Text);
                            Text = scanner.nextLine();
                        }
                }

                    if (Objects.equals(privateChatText, "reply")) {
                        while (!Objects.equals(Text, "exit")) {
                        System.out.println("Enter the number message you want to reply :-exit");
                        Text = scanner.nextLine();
                        String temp = modle.PrivateChat.findMessage(username, username2, Integer.parseInt(Text));
                        System.out.println("Enter the text you want to send user : ");
                        Text = scanner.nextLine();
                            modle.  PrivateChat.privateChat(username, username2, temp + "....\n" + Text);
                            System.out.println("Enter the number message you want to reply :-exit");
                            Text=scanner.nextLine();
                    }
                }


                    if (Objects.equals(privateChatText, "forward")) {
                        System.out.println("Enter the number message you want to forward :-exit");
                        Text = scanner.nextLine();
                        while (!Objects.equals(Text, "exit")) {
                        String message = modle.PrivateChat.findMessageForward(username, username2, Text);
                        System.out.println("Enter the username with you want to send forward message : ");
                        username2 = scanner.nextLine();
                        forwardChat(username, username2, message);
                            System.out.println("Enter the number message you want to forward :-exit");
                            Text = scanner.nextLine();
                    }
                }


                    if (Objects.equals(privateChatText, "edit")) {
                        System.out.println("Enter the number message you want to edit :-exit");
                        Text = scanner.nextLine();
                        while (!Objects.equals(privateChatText, "exit")) {

                        String oldchat = modle.PrivateChat.findMessage(username, username2, Integer.parseInt(Text));
                        System.out.println("Enter the text you want replace message : ");
                        String newchat = scanner.nextLine();
                            modle. PrivateChat.editMessage(username, username2, oldchat, newchat);
                            System.out.println("Enter the number message you want to edit :-exit");
                            Text = scanner.nextLine();
                    }
                }

                    if (Objects.equals(privateChatText, "delete")) {
                        System.out.println("Enter the number message you want to delete :-exit");
                        Text = scanner.nextLine();
                        while (!Objects.equals(privateChatText, "exit")) {
                        String oldchat = modle.PrivateChat.findMessage(username, username2, Integer.parseInt(Text));
                            modle.PrivateChat.deleteMessage(username, username2, oldchat);
                            System.out.println("Enter the number message you want to delete :-exit");
                            Text = scanner.nextLine();
                    }
                }
                System.out.println("Enter one of send message-reply-forward-edit-delete-exit");
                privateChatText = scanner.nextLine();
            }
        }
    }

    public static void forwardChat(String username,String username2,String forward) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
        Connection  conn = getConnection(url);
        Scanner scanner = new Scanner(System.in);

        if (tableExist( "blockedUser_" + username2)){
            if (modle.Block.checkBlock(username2,username));{
                System.out.println("you blocked cant send message");
                return;
            }
        }
        while (!tableExist(username2)){
                return;
        }
        int a= username.compareTo(username2);
        String nameChat;
        if(a>0){
            nameChat="privateChat_"+username+"_"+username2;
        }
        else {
            nameChat="privateChat_"+username2+"_"+username;
        }
        nameChat=nameChat.toLowerCase(Locale.ROOT);

        String privateChatText = "";
        if(!tableExist(nameChat)){
            // start chat
            modle.PrivateChat.startPrivateChat(username, username2, forward);
            //continue chat
        }
        else {

            modle. PrivateChat.ShowChat(username,username2);
                    modle.PrivateChat.privateChat(username, username2,forward);
        }
    }

    public static void blockUser(String username) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
        Connection  conn = getConnection(url);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter exit for next step");
        System.out.println("BLOCK user: enter username of the people with you want block ");
        String username2 = scanner.nextLine();
        while (!Objects.equals(username2, "exit")){
            if (!modle.Block.checkBlock(username,username2)){
                //
                modle. Block.addUserBlocked(username, username2);
            }
            else System.out.println("you already blocked user");
           username2 = scanner.nextLine();
        }
    }

    public static void unblock(String username) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
        Connection  conn = getConnection(url);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter exit for next step");
        System.out.println("UNBLOCK user: enter username of the people with you want unblock ");
        String username2 = scanner.nextLine();
            while (!Objects.equals(username2, "exit")) {
                if (modle.Block.checkBlock(username,username2)){
                    System.out.println("you unblock user");
                    modle. Block.unblocked(username, username2);
                }
                else System.out.println("user wasnt block");
                username2 = scanner.nextLine();
            }
        }

    public static boolean tableExist( String tableName) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
      String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
      Connection  conn = DriverManager.getConnection(url);
        tableName=tableName.toLowerCase(Locale.ROOT);
        boolean tExists = false;
        try (ResultSet rs = conn.getMetaData().getTables(null, null, tableName, null)) {
            while (rs.next()) {
                String tName = rs.getString("TABLE_NAME");
                if (tName != null && tName.equals(tableName)) {
                    tExists = true;
                    break;
                }
            }
        }
        return tExists;
    }

}

