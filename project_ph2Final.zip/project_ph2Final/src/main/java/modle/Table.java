package modle;

import java.sql.*;

public class Table {
    public static String find_text (String table_name , int ans_row , int ans_clu  )
    {
        String answer = "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select * from %s";
            query = String.format(query , table_name);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            // Iterate through the data in the result set and display it.
            int counter_row = 1 ;
            while (rs.next()) {
                if(counter_row==ans_row) {
                    answer = rs.getString(ans_clu);
                    return answer;
                }
                else
                    counter_row++;
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();{
                e.printStackTrace();
            }
        } catch (IllegalAccessException e) {

        }
        return answer;
    }
}
