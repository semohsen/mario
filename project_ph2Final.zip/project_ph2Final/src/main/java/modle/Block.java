package modle;

import java.sql.*;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Objects;

public class Block {

    public static void blockUser(String username) {
        String blockUser = ("blockedUser_"+username).toLowerCase(Locale.ROOT);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "CREATE TABLE %s (blockedUser varchar(40))";
            query = String.format(query, blockUser);
            state.execute(query);
            state.close();
            connect.close();
        } catch (SQLException | ClassNotFoundException | InstantiationException |
                IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static void addUserBlocked(String username, String username2) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "INSERT INTO %s Values ('%s')";
            query = String.format(query, "blockedUser_" + username, username2);
            state.execute(query);
            state.close();
            connect.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        System.out.println("add successful");
    }

    public static void unblocked(String username, String username2) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "DELETE FROM %s WHERE blockedUser='%s'";
            query = String.format(query, "blockedUser_" + username, username2);
            state.execute(query);
            state.close();
            connect.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        System.out.println("add successful");
    }

    public static boolean checkBlock(String username, String username2) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select blockedUser from %s ";
            query = String.format(query, "blockedUser_" + username);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            int counter = 1;
            boolean print = false;
            while (rs.next()) {
                //Print one row
                for (int i = 1; i <= columnsNumber; i++) {
                    if (rs.getString(i) != null) {
                        String sent = rs.getString(i);
                        if (Objects.equals(username2, sent)) {
                              return true ;
                        }
                    }
                }
                counter++;
            }
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void showBlockedUser(String username){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select blockedUser from %s ";
            query = String.format(query ,"blockedUser_" + username);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            int counter = 1 ;
            boolean print = false ;
            while (rs.next()) {
                //Print one row
                for(int i = 1 ; i <= columnsNumber; i++){
                    if(rs.getString(i)!=null) {
                        String sent = rs.getString(i);
                        System.out.print(counter + "-" + sent + " "); //Print one element of a row
                        print = true ;
                    }
                }
                counter++;
                System.out.println();//Move to the next line to print the next row.
            }
            if(!print)
                System.out.println("NO USER FOUND ");
        }
        catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static ArrayList showBlockedUserGraphic(String username){
       ArrayList<Object> blockUser=new ArrayList<>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select blockedUser from %s ";
            query = String.format(query ,"blockedUser_" + username);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            int counter = 1 ;
            boolean print = false ;
            while (rs.next()) {
                //Print one row
                for(int i = 1 ; i <= columnsNumber; i++){
                    if(rs.getString(i)!=null) {
                        String sent = rs.getString(i);
                        blockUser.add(sent);
                        System.out.print(counter + "-" + sent + " "); //Print one element of a row
                        print = true ;
                    }
                }
                counter++;
                System.out.println();//Move to the next line to print the next row.
            }
            if(!print)
                System.out.println("NO USER FOUND ");
        }
        catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return blockUser;
    }
}
