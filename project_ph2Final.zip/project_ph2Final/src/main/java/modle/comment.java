package modle;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Scanner;

public class comment {
    public static String answer = "";
    public static String timeTweet = "";
    public static void Just_Start(String username,  int number){
        findTweet(username , number);
        String tweet = answer;
        tweet = tweet.trim();
        String target = tweet.substring(tweet.indexOf('-')+1 , tweet.indexOf(' '));
        String timeStamp = Timetweet(target , number);
        timeTweet = timeStamp ;
    }

    public static void addComment (String username , int number , String comment)
    {
        findTweet(username , number);
       String tweet = answer;
       tweet = tweet.trim();
       String target = tweet.substring(tweet.indexOf('-')+1 , tweet.indexOf(' '));
        String timeStamp = Timetweet(target , number);
        timeTweet = timeStamp ;
        System.out.println("Enter your comment : ");
        comment = "comment_"+ username + " : " + comment;

            try {
                Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
                String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
                Connection connect = DriverManager.getConnection(url);
                Statement state = connect.createStatement();
                String query = "INSERT INTO %s (tweets , time ) VALUES ('%s' , '%s_%s' )";
                String table_name = target + "_tweet";
                 query = String.format(query, table_name, comment, timeStamp, "comment");
                state.execute(query);
                state.close();
                connect.close();
                System.out.println("your comment is sent . ");
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }


    public static void  findTweet (String username , int number)
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select timeline from %s";
            String temp = username+"_timeline";
            query = String.format(query , temp);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            int counter = 0 ;
            boolean find = false ;
            while (rs.next() && !find) {
                //Print one row
                 counter++;
                for(int i = 1 ; i <= columnsNumber; i++){
                    if(counter == number)
                    {
                        find = true ;
                        answer = rs.getString(i);
                    }
                }
            }
            if(find)
                return ;
        }
        catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static void deleteComment (String username , String owner , int tweet_number)
    {
        System.out.println("What is the number of comment you want to delete ? ");
        Scanner scanner = new Scanner(System.in);
        String delet_text = "";
        int comment_number = scanner.nextInt();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select tweets from %s where time ='%s' ";
            String temp = owner+"_tweet";
            String target = answer.substring(answer.indexOf(':')+2);
            Just_Start(username , tweet_number);
            String time = timeTweet+"_comment";
            query = String.format(query , temp , time);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            int counter = 1 ;
            while (rs.next()) {
                for(int i = 1 ; i <= columnsNumber; i++){
                    if(rs.getString(i)!=null) {
                        if(counter == comment_number)
                        {
                            delet_text= rs.getString(i);
                        }
                    }
                }
                counter++;
            }
            query ="DELETE FROM %s WHERE tweets='%s'";
            owner = owner+"_tweet";
            query = String.format(query , owner , delet_text);
            state.execute(query);
            state.close();
            connect.close();
            System.out.println("comment is deleted . ");
        }
        catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public static void ShowComment (String username , int number , String owner) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select tweets from %s where time ='%s' ";
            String temp = owner+"_tweet";
            String target = answer.substring(answer.indexOf(':')+2);
            Just_Start(username , number);
            String time = timeTweet+"_comment";

            query = String.format(query , temp , time);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            // Iterate through the data in the result set and display it.
            System.out.println("---------------------------------------------------------------");
            int counter = 1 ;
            boolean print = false ;
            while (rs.next()) {
                //Print one row
                for(int i = 1 ; i <= columnsNumber; i++){
                    if(rs.getString(i)!=null) {
                        String sent = rs.getString(i).substring(8);
                        System.out.print(counter + "-" + sent + " "); //Print one element of a row
                        print = true ;
                    }
                }
                counter++;
                System.out.println();//Move to the next line to print the next row.
            }
            if(!print)
                System.out.println("NO COMMENT FOUND ");
            System.out.println("---------------------------------------------------------------");
        }
        catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    public static String Timetweet (String username , int number )
    {
        String time ="";
        findTweet(username , number);
        String tweet = answer;
        int index = tweet.indexOf(':')+2;
        tweet = tweet.substring(index);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection connect = DriverManager.getConnection(url);
            Statement state = connect.createStatement();
            String query = "select time from %s where tweets='%s'";
            String temp = username+"_tweet";
            query = String.format(query , temp , tweet);
            ResultSet rs = state.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            // Iterate through the data in the result set and display it.
            int counter = 1 ;
            while (rs.next()) {
                //Print one row
                for(int i = 1 ; i <= columnsNumber; i++){
                    time = rs.getString(i);
                }
                counter++;
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return time ;
    }
    public static String findOwner (String username , int number)
    {
        String owner ="";
        findTweet(username , number);
        String tweet = answer;
        tweet = tweet.trim();
        owner = tweet.substring(tweet.indexOf('-')+1 , tweet.indexOf(' '));
        return owner;
    }
    public static String FindTableName (String username , int tweet_number )
    {
        String table_name ="";
        Just_Start(username , tweet_number);
        String target = answer.substring(0 , answer.indexOf(':')-1);
        timeTweet = Timetweet(target , tweet_number);
        table_name = "like_"+target+"_"+timeTweet;
        return table_name;
    }
}
