package com.example.project_ph2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import modle.Block;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

//import static com.example.project_ph2.Data.blockUser;
import static java.sql.DriverManager.getConnection;
import static view.InputProcessor.tableExist;
import static com.example.project_ph2.Data.*;

public class Privacy implements Initializable {

    private Stage stage ;
    private Scene scene ;
    private Parent root ;
    static String username=login_controller.user;
    @FXML
    private TextField usernameBlock ;
    @FXML
    private TextField usernameUnBlock ;
    @FXML
    private Label LabelAddBlock;

    public void backSetting(javafx.event.ActionEvent event) throws IOException {
        System.out.println("Setting ...");
        Parent root = FXMLLoader.load(getClass().getResource("Settings.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
        // Main.changeMenu("Settings",new Stage());
    }

    //showBlockedUserGraphic
    @FXML
    public ChoiceBox<String> AccountType=new ChoiceBox<>();

   ArrayList blockUser=Block.showBlockedUserGraphic(username);

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        System.out.println(blockUser);
        AccountType.getItems().addAll(blockUser);


    }

    public void AddBlock(ActionEvent event) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        System.out.println("BLOCK user: enter username of the people with you want block ");
        String username2 = usernameBlock.getText();
        LabelAddBlock.setText("trhheyne5yj");
        if (!tableExist(username2)) {
            System.out.println("1");
            String s="username doesn't exist";
            LabelAddBlock.setText(s);
            return;
        }
            if (!modle.Block.checkBlock(username,username2)) {
                System.out.println("2");
                modle.Block.addUserBlocked(username, username2);
                LabelAddBlock.setText("you block user");
            }
            else
                LabelAddBlock.setText("you already blocked user");
               // System.out.println("you already blocked user");
        }



    public void unBlock(ActionEvent event) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        System.out.println("UNBLOCK user: enter username of the people with you want unblock ");
        String username2 = usernameUnBlock.getText();
        if (!tableExist(username2)) {
            LabelAddBlock.setText("username doesn't exist");
            return;
        }
        if (modle.Block.checkBlock(username,username2)){
            LabelAddBlock.setText("you unblock user");
            modle. Block.unblocked(username, username2);
        }
        else LabelAddBlock.setText("user wasn't block");

    }
}

