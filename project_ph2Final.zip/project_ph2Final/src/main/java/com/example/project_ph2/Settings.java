package com.example.project_ph2;

import com.example.project_ph2.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class Settings {

    private Stage stage ;
    private Scene scene ;
    private Parent root ;
    //Settings
    @FXML
    private Label LabelUsername;

    public void ChangeProfileButton(javafx.event.ActionEvent event) throws IOException {
        System.out.println("Picture Profile...");
       // Main.changeMenu("PictureProfile",new Stage());
    }

    public void backTreeLine(javafx.event.ActionEvent event) throws IOException {
        System.out.println("Setting ...");
        Parent root = FXMLLoader.load(getClass().getResource("TreeLine.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
       // Main.changeMenu("Settings",new Stage());
    }

    public void PrivacyAndSecurityButton(javafx.event.ActionEvent event) throws IOException {
        System.out.println("Privacy...");
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Privacy.fxml")));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
        //Main.changeMenu("Privacy",new Stage());
    }
}
