package com.example.project_ph2;

import com.example.project_ph2.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.awt.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Locale;

import static view.InputProcessor.tableExist;

public class MainPageController  {

    private Stage stage ;
    private Scene scene ;
    private Parent root ;
    String username=login_controller.user;

    public javafx.scene.control.TextField registerUsername2Input;
    public javafx.scene.control.Label LabelUsername2;
    //public TextField getRegisterUsername2Input;
//    @FXML
//    private Label getLabelUsername2;

    static String username2="";
    //MainPage
    public void allChatButtonClicked() throws IOException {
        System.out.println("tree Line...");
       // Main.changeMenu("TreeLine",new Stage());
    }

        public void startChatButtonClicked(javafx.event.ActionEvent event) throws IOException, SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        System.out.println("Chat Page...");
        username2= registerUsername2Input.getText();
            if (username2.equals("")) {
                LabelUsername2.setText("pleas Enter username2");
                return;
            }
            if (!tableExist(username2)){
                System.out.println(" username dosent exist enter username with is exist:");
                LabelUsername2.setText(" username dosent exist enter username with is exist:");
            }

            if (modle.Block.checkBlock(username2,username)){
                System.out.println("you was blocked can't send message");
                LabelUsername2.setText("you was blocked can't send message");
                return;
            }

            int a= username.compareTo(username2);
            String nameChat;
            if(a>0){
                nameChat="privateChat_"+username+"_"+username2;
            }
            else {
                nameChat="privateChat_"+username2+"_"+username;
            }
            nameChat=nameChat.toLowerCase(Locale.ROOT);

            //ChatPage.chatPage(username,username2,nameChat);
            Parent root = FXMLLoader.load(getClass().getResource("ChatShow.fxml"));
            stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            String css = this.getClass().getResource("timelineStyleDark.css").toExternalForm();
            scene.getStylesheets().add(css);
            stage.setScene(scene);
            stage.show();
            username2="";
    }

    public void logout_time(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }

//    public void treeLineButtonClicked(javafx.event.ActionEvent event) throws IOException {
//        System.out.println("tree Line...");
//        Parent root = FXMLLoader.load(getClass().getResource("TreeLine.fxml"));
//        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
//        scene = new Scene(root);
//        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
//        scene.getStylesheets().add(css);
//        stage.setScene(scene);
//        stage.show();
//       //Main.changeMenu("TreeLine",new Stage());
//    }

//    public void groupsButtonClicked(javafx.event.ActionEvent event) throws IOException {
//        System.out.println("myGroup...");
//        Parent root = FXMLLoader.load(getClass().getResource("myGroup.fxml"));
//        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
//        scene = new Scene(root);
//        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
//        scene.getStylesheets().add(css);
//        stage.setScene(scene);
//        stage.show();
//    }

    public void usersButtonClicked(javafx.event.ActionEvent event) throws IOException {
        System.out.println("tree Line...");
        //Main.changeMenu("TreeLine",new Stage());
    }

    public void searchUser() throws IOException {
        System.out.println("tree Line...");
       // Main.changeMenu("TreeLine",new Stage());
    }
}
