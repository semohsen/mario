package com.example.project_ph2;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.Locale;
import java.util.Objects;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
//import modle.Like;

import static java.lang.Class.forName;

public class NotificationsController implements Initializable {
    private Stage stage ;
    private Scene scene ;
    private Parent root ;
    String username=login_controller.user;
    static String groupName;

    @FXML private TableView<Tweet> tableViewTweet;
    @FXML private TableColumn<Tweet, String> tweet;
    @FXML private TextField textFieldSelectGroup;

    public javafx.scene.control.Label labelFriendRequest;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        tweet.setCellValueFactory(new PropertyValueFactory<Tweet, String>("tweet"));
        try {
            tableViewTweet.setItems(getMyTweet());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    public static Connection conn = null;
    //private ObservableList data;
    public ObservableList<Tweet> getMyTweet() throws ClassNotFoundException/* throws ClassNotFoundException*/{
        String firstGroupUser = username+"_timeline";
        ObservableList<Tweet> tweet = FXCollections.observableArrayList();
//        myGroup.add(new MyGroup("Frank",username));
        try{
            forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection conn = DriverManager.getConnection(url);
            Statement state = conn.createStatement();
            tweet = FXCollections.observableArrayList();
            String query = "select timeline from %s ";
            query = String.format(query, firstGroupUser);
            ResultSet rs = state.executeQuery(query);
            while(rs.next()) {
                tweet.add(new Tweet(rs.getString(1)));
            }
        }catch(SQLException | InstantiationException | IllegalAccessException ex){
            System.err.println("Error" + ex);
        }

        return tweet;
    }

    public void backMainPage(javafx.event.ActionEvent event) throws IOException {
        System.out.println("Setting ...");
        Parent root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }


    public void logout_fromTweet(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void chat_fromTweet(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ChatShow.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }

    public void newMessage_fromNotification(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ChatShow.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }

    public void friendRequest_fromNotification(javafx.event.ActionEvent event) throws IOException {
        labelFriendRequest.setText(" username dosent exist enter username with is exist:");
        //        Parent root = FXMLLoader.load(getClass().getResource("ChatShow.fxml"));
//        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
//        scene = new Scene(root);
//        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
//        scene.getStylesheets().add(css);
//        stage.setScene(scene);
//        stage.show();
    }

    public void playRequest_fromNotification(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ChatShow.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void deportRoom_fromNotification(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ChatShow.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }

    public void newItem_fromNotification(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ChatShow.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void darkmood(javafx.event.ActionEvent event) throws IOException {
        login_controller.mood ++;
        if( login_controller.mood==3)
            login_controller.mood=1;
        if( login_controller.mood==1) {
            Parent root = FXMLLoader.load(getClass().getResource("tweet.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            String css = this.getClass().getResource("timelineStyle.css").toExternalForm();
            scene.getStylesheets().add(css);
            stage.setScene(scene);
            stage.show();
        }
        else
        {
            Parent root = FXMLLoader.load(getClass().getResource("tweet.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            String css = this.getClass().getResource("timelineStyleDark.css").toExternalForm();
            scene.getStylesheets().add(css);
            stage.setScene(scene);
            stage.show();
        }
    }
    @FXML
    TextField comment ;
    public static int comment_number ;
    public void comment(javafx.event.ActionEvent event) throws IOException {
        comment_number = Integer.parseInt(String.valueOf(comment.getText()));
        Parent root = FXMLLoader.load(getClass().getResource("comment.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
}



