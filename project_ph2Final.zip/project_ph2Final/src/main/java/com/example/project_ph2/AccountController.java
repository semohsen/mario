package com.example.project_ph2;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;

public class AccountController implements Initializable {

   // Account
    @FXML
    public ChoiceBox<String> AccountType;
    private String[]Accounttype={"Normal","Business"};
    @FXML
    private Label LabelAccountType;
    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        AccountType.getItems().addAll(Accounttype);
        AccountType.setOnAction(this::getType);
    }

    public void getType(javafx.event.ActionEvent event){
        String AccounttType=AccountType.getValue();
        LabelAccountType.setText(AccounttType);
    }
}
