package com.example.project_ph2;

import modle.Block;

import java.util.ArrayList;



public class Data {

    static String username=login_controller.user;
    protected static ArrayList blockUser=new ArrayList<>();

    //private ArrayList blockUser= Block.showBlockedUserGraphic(username);
}
