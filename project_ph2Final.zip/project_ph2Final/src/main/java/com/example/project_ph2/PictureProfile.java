package com.example.project_ph2;

import com.example.project_ph2.Main;
import javafx.stage.Stage;

import java.io.IOException;

public class PictureProfile {
    // TODO: 8/5/2022
    public void BackSettingsClicked() throws IOException {
        System.out.println("Settings...");
      //  Main.changeMenu("Settings",new Stage());
    }



}
