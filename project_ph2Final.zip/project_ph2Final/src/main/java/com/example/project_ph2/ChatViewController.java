package com.example.project_ph2;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.Locale;
import java.util.Objects;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import modle.Block;
import view.InputProcessor;

import static java.lang.Class.forName;
import static view.InputProcessor.tableExist;

public class ChatViewController implements Initializable {
    private Stage stage ;
    private Scene scene ;
    private Parent root ;
    String username=login_controller.user;
    String usernameb=MainPageController.username2;

    @FXML
    private Label LabelCheckBlock;
    public TextField registerChatInput;
    public TextField registerNumberInput;
    //configure the table
    @FXML private TableView<ChatShow> tableViewChat;
    @FXML private TableColumn<ChatShow, String> chatId;
    @FXML private TableColumn<ChatShow, String> username1;
    @FXML private TableColumn<ChatShow, String> username2;
    @FXML private TableColumn<ChatShow, String> time;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        chatId.setCellValueFactory(new PropertyValueFactory<ChatShow, String>("chatId"));
        username1.setCellValueFactory(new PropertyValueFactory<ChatShow, String>("username1"));
        username2.setCellValueFactory(new PropertyValueFactory<ChatShow, String>("username2"));
        time.setCellValueFactory(new PropertyValueFactory<ChatShow, String>("time"));
        try {
            tableViewChat.setItems(getChat());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public ObservableList<ChatShow>  getChat() throws ClassNotFoundException {
        int a= username.compareTo(usernameb);
        String nameChat;
        if(a>0){
            nameChat="privateChat_"+username+"_"+usernameb;
        }
        else {
            nameChat="privateChat_"+usernameb+"_"+username;
        }
        ObservableList<ChatShow> chatShows = FXCollections.observableArrayList();
        nameChat = ("group_" + nameChat).toLowerCase(Locale.ROOT);
        System.out.println(nameChat);
        try{
            forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection conn = DriverManager.getConnection(url);
            Statement state = conn.createStatement();
            chatShows = FXCollections.observableArrayList();
            String query = "select * from %s ";
            query = String.format(query, nameChat);
            ResultSet rs = state.executeQuery(query);
            while(rs.next()) {
                System.out.println(rs.getString(4)+rs.getString(5));
                if(!Objects.equals(rs.getString(1), "")&!Objects.equals(rs.getString(2), "")&!Objects.equals(rs.getString(3), "")&!Objects.equals(rs.getString(3), ""))
                    chatShows.add(new ChatShow(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)));
            }
        }catch(SQLException | InstantiationException | IllegalAccessException ex){
            System.err.println("Error" + ex);
        }
        return chatShows;
    }

    public void backMainPage(javafx.event.ActionEvent event) throws IOException {
        System.out.println("main page ...");
        Parent root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }

    public void sendChat(javafx.event.ActionEvent event) throws IOException, ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        if (!tableExist(usernameb)) {
            LabelCheckBlock.setText(" username doesn't exist enter username with is exist:");
            System.out.println(" username doesn't exist enter username with is exist:");
            return;
        }

        if (Block.checkBlock(usernameb, username)) {
            LabelCheckBlock.setText("you was blocked can't send message");
            System.out.println("you was blocked can't send message");
            return;
        }
        int a = username.compareTo(usernameb);
        String nameChat;
        if (a > 0) {
            nameChat = "privateChat_" + username + "_" + usernameb;
        } else {
            nameChat = "privateChat_" + usernameb + "_" + username;
        }
        if(!tableExist(nameChat)){
            System.out.println("Enter the text you want to send user :");
           String privateChatText=registerChatInput.getText();
            // start chat
            modle. PrivateChat.startPrivateChat(username, usernameb, privateChatText);
            //continue chat
            modle. PrivateChat.ShowChat(username,usernameb);
        }
        else {
            modle. PrivateChat.ShowChat(username,usernameb);
                    System.out.println("Enter the text you want to send user : -exit");
                  String Text=registerChatInput.getText();
            modle.PrivateChat.privateChat(username, usernameb,Text);
                    }
                }

    public void replyChat(javafx.event.ActionEvent event){
            System.out.println("Enter the number message you want to reply :-exit");
            String number=registerNumberInput.getText();
            String temp = modle.PrivateChat.findMessage(username, usernameb, Integer.parseInt(number));
            System.out.println("Enter the text you want to send user : ");
            String Text=registerChatInput.getText();
            modle.PrivateChat.privateChat(username, usernameb, temp + "....\n" + Text);
    }

    public void forwardChat(javafx.event.ActionEvent event) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        System.out.println("Enter the number message you want to forward :-exit");
        String number=registerNumberInput.getText();
            String message = modle.PrivateChat.findMessageForward(username, usernameb,number);
            System.out.println("Enter the username with you want to send forward message : ");
           String usernamec =registerChatInput.getText();
           InputProcessor.forwardChat(username, usernamec, message);
    }

    public void EditChat(javafx.event.ActionEvent event){
            System.out.println("Enter the number message you want to edit :-exit");
        String number=registerNumberInput.getText();
                String oldchat = modle.PrivateChat.findMessage(username, usernameb, Integer.parseInt(number));
                System.out.println("Enter the text you want replace message : ");
        String newchat =registerChatInput.getText();
                modle. PrivateChat.editMessage(username, usernameb, oldchat, newchat);
            }

    public void deleteChat(javafx.event.ActionEvent event){
            System.out.println("Enter the number message you want to delete :-exit");
        String number=registerNumberInput.getText();
                String oldchat = modle.PrivateChat.findMessage(username, usernameb, Integer.parseInt(number));
                modle.PrivateChat.deleteMessage(username, usernameb, oldchat);
            }
    }

