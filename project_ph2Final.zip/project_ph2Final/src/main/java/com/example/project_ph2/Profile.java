package com.example.project_ph2;

import javafx.beans.property.SimpleStringProperty;

public class Profile {
    private SimpleStringProperty profile;

    public Profile(String tweet) {
        this.profile = new SimpleStringProperty(tweet);
    }

    public String getProfile() {
        return profile.get();
    }

    public void setProfile(String group) {
        this.profile.set(group);
    }


    public String toString() {
        return String.format("%s",profile);
    }
}

