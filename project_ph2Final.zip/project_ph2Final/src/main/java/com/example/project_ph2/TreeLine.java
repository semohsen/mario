package com.example.project_ph2;

import com.example.project_ph2.Main;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class TreeLine {
    private Stage stage ;
    private Scene scene ;
    private Parent root ;
    public void NewGroupButton(javafx.event.ActionEvent event) throws IOException {
        System.out.println("new Group...");
        Parent root = FXMLLoader.load(getClass().getResource("newGroup.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
        //Main.changeMenu("newGroup",new Stage());
    }

    public void FollowerButton(javafx.event.ActionEvent event) throws IOException {
        // TODO: 8/5/2022 hosein
    }

    public void FollowingButton(javafx.event.ActionEvent event) throws IOException {
        // TODO: 8/5/2022 hosein
    }

    public void SettingButton(javafx.event.ActionEvent event) throws IOException {
        System.out.println("Setting ...");
        Parent root = FXMLLoader.load(getClass().getResource("Settings.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
       // Main.changeMenu("Settings",new Stage());
    }

    public void backMainPage(javafx.event.ActionEvent event) throws IOException {
        System.out.println("Main Page ...");
        Parent root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
        //Main.changeMenu("MainPage",new Stage());
    }

    public void ChangeProfileButton(javafx.event.ActionEvent event) throws IOException {
        // TODO: 8/5/2022 mohsen
//        System.out.println("Picture Profile...");
//        Main.changeMenu("PictureProfile",new Stage());
    }
}
