package com.example.project_ph2;

import javafx.beans.property.SimpleStringProperty;

public class Tweet {
    private SimpleStringProperty tweet;

    public Tweet(String tweet) {
        this.tweet = new SimpleStringProperty(tweet);
    }

    public String gettweet() {
        return tweet.get();
    }

    public void settweet(String group) {
        this.tweet.set(group);
    }


    public String toString() {
        return String.format("%s",tweet);
    }
}

