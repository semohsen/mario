package com.example.project_ph2;

import javafx.beans.property.SimpleStringProperty;
import javafx.scene.image.Image;

import java.time.LocalDate;
import java.time.Period;

/**
 * @author jwright
 */
public class ChatShow {
    private SimpleStringProperty chatId,username,username2, time;

    public ChatShow(String  chatId, String  username, String  username2, String  time) {
        this.chatId =new  SimpleStringProperty(chatId);
        this.username =new  SimpleStringProperty(username);
        this.username2 =new  SimpleStringProperty(username2);
        this.time =new  SimpleStringProperty(time);
    }

    public String getChatId() {
        return chatId.get();
    }


    public String getUsername() {
        return username.get();
    }


    public String getUsername2() {
        return username2.get();
    }

    public String getTime() {
        return time.get();
    }

    public void setChatId(String chatId) {
        this.chatId.set(chatId);
    }

    public void setUsername(String username) {
        this.username.set(username);
    }

    public void setUsername2(String username2) {
        this.username2.set(username2);
    }

    public void setTime(String time) {
        this.time.set(time);
    }

    public String toString() {
        return String.format("%s %s %s %s",chatId,username,username2, time);
    }
}
