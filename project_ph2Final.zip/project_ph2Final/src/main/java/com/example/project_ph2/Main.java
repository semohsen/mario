package com.example.project_ph2;
//Mm123456!
import controller.Manager;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Objects;

public class Main extends Application {
    private static Scene scene;
    @Override
    public void start(Stage stage) throws IOException {
        Parent root = FXMLLoader.load((getClass().getResource("login.fxml")));
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        Scene scene = new Scene(root);
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
//        Parent root = loadFXML("ChatPage");
//        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
//        Scene scene = new Scene(root);
//        Main.scene = scene;
//        scene.getStylesheets().add(css);
//        stage.setScene(scene);
//        stage.show();
    }

    public static void main(String[] args) throws SQLException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {

        try {
            File myObj = new File("messageId.txt");
            if (myObj.createNewFile()) {
                System.out.println("File created: " + myObj.getName());
            } else {
                System.out.println("File already exists.");
            }

        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        Manager manager = new Manager();
        view.InputProcessor inputProcessor = new view.InputProcessor(manager);
        launch();
    }

//    public static void changeMenu(String name,Stage stage2) {
//        Parent root = loadFXML(name);
//        Main.scene.setRoot(root);
//    }

//    private static Parent loadFXML(String name) {
//        try {
//            URL address = new URL(Main.class.getResource( name + ".fxml").toString());
//            return FXMLLoader.load(address);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
}