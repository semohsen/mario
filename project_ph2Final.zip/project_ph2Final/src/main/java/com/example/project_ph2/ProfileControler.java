package com.example.project_ph2;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.Locale;
import java.util.Objects;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import static java.lang.Class.forName;

public class ProfileControler implements Initializable {
    private Stage stage ;
    private Scene scene ;
    private Parent root ;
    String username=login_controller.user;

    @FXML private TableView<Profile> tableViewProfile;
    @FXML private TableColumn<Profile, String> Profile;
    @FXML private TextField textFieldSelectGroup;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Profile.setCellValueFactory(new PropertyValueFactory<Profile, String>("profile"));

        try {
            tableViewProfile.setItems(getMyProfile());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static Connection conn = null;
    //private ObservableList data;

    public ObservableList<Profile> getMyProfile() throws ClassNotFoundException/* throws ClassNotFoundException*/{
        String firstGroupUser = username+"_tweet";
        ObservableList<Profile> profile = FXCollections.observableArrayList();
//        myGroup.add(new MyGroup("Frank",username));
        try{
            forName("com.mysql.cj.jdbc.Driver").newInstance();
            String url = "jdbc:mysql://localhost/game?user=root&password=13811351";
            Connection conn = DriverManager.getConnection(url);
            Statement state = conn.createStatement();
            profile = FXCollections.observableArrayList();
            String query = "select tweets from %s ";
            query = String.format(query, firstGroupUser);
            ResultSet rs = state.executeQuery(query);
            while(rs.next()) {
                profile.add(new Profile(rs.getString(1)));
            }
        }catch(SQLException | InstantiationException | IllegalAccessException ex){
            System.err.println("Error" + ex);
        }

        return profile;
    }

    public void backMainPage(javafx.event.ActionEvent event) throws IOException {
        System.out.println("Setting ...");
        Parent root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }

    public void Timeline(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("tweet.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void setting_fromTweet(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Settings.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }public void logout_fromTweet(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }public void recommend_tweet(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("recommend.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }public void AD_fromTimeline(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ad.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }public void chat_fromTweet(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ChatShow.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void Post_fromTweet(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("post.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void darkmood(javafx.event.ActionEvent event) throws IOException {
        login_controller.mood ++;
        if( login_controller.mood==3)
            login_controller.mood=1;
        if( login_controller.mood==1) {
            Parent root = FXMLLoader.load(getClass().getResource("tweet.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            String css = this.getClass().getResource("timelineStyle.css").toExternalForm();
            scene.getStylesheets().add(css);
            stage.setScene(scene);
            stage.show();
        }
        else
        {
            Parent root = FXMLLoader.load(getClass().getResource("tweet.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            String css = this.getClass().getResource("timelineStyleDark.css").toExternalForm();
            scene.getStylesheets().add(css);
            stage.setScene(scene);
            stage.show();
        }
    }

}


