package com.example.project_ph2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import modle.ForgetPassword;
import modle.UserInfo;
import view.InputProcessor;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Objects;
import java.util.ResourceBundle;

import javafx.scene.image.*;
public class login_controller implements Initializable {
    @FXML
    private Label label ;
    @FXML
    private Label Forgot_label ;
    @FXML
    private Label Signup_label ;
    @FXML
    private Label timeline_username ;
    @FXML
    private TextField username ;
    @FXML
    private PasswordField PassWord ;
    @FXML
    private PasswordField Signup_pass1 ;
    @FXML
    private PasswordField Signup_pass2 ;
    @FXML
    private TextField Hero ;
    @FXML
    private TextField City ;
    @FXML
    private TextField Forgot_City ;
    @FXML
    private TextField Forgot_username ;
    @FXML
    private TextField Forgot_hero ;
    @FXML
    private PasswordField ForgotPassword1 ;
    @FXML
    private PasswordField ForgotPassword2 ;
    @FXML
    private TextField signup_username ;
    public static String user ;
    String pass ;
    String pass_check ;
    String city ;
    String hero ;
    private Stage stage ;
    private Scene scene ;
    @FXML
    Button back ;
    public static int mood =1 ;
    public void login(javafx.event.ActionEvent actionEvent) throws SQLException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
            user = username.getText();
            pass = PassWord.getText();
            String model = user+"-"+pass;
            String set =  modle.Login.loginuser(model);
            label.setText(set);
            if(set.equals("You Are Login ..."))
            {
               Parent root = FXMLLoader.load(getClass().getResource("tweet.fxml"));
                stage = (Stage) ((Node)actionEvent.getSource()).getScene().getWindow();
                scene = new Scene(root);
                String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
                scene.getStylesheets().add(css);
                stage.setScene(scene);
                stage.show();
            }
        }
//    public void initialize (){
//        Image playI=new Image("C:\\Users\\hp\\Desktop\\java\\project_ph2\\src\\main\\resources\\com\\example\\project_ph2\\Image\\back.png");
//        ImageView iv1=new ImageView(playI);
//        back=new Button();
//        back.setGraphic(iv1);
//    }

    public void signup( javafx.event.ActionEvent event) throws SQLException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException{
        Parent root = FXMLLoader.load(getClass().getResource("signup.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void back(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void submit(javafx.event.ActionEvent event) throws SQLException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        user = signup_username.getText();
        String what = "try another username";
        what = modle.Signup.result_findUser(user);
        Signup_label.setText(what);
       if(!what.equals("try another username"))
       {
           pass = Signup_pass1.getText();
           pass_check = Signup_pass2.getText();
           what = UserInfo.result_makepassword(pass , pass_check);
           Signup_label.setText(what);
           if(what.equals("weak"))
               Signup_label.setText("your password is weak");
           if(what.equals("strong"))
           {
               Signup_label.setText("you can login now");
               modle.Signup.makeUser(user , pass);
               city = City.getText();
               hero = Hero.getText();
               String forget = username+"-"+city+"-"+hero;
               ForgetPassword.makeIt(forget);
           }
       }
    }
    public void forgot(javafx.event.ActionEvent event) throws SQLException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException  {
        Parent root = FXMLLoader.load(getClass().getResource("forgotpassword.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }

    public void ForgotPassword(ActionEvent event) throws IOException {
        user =Forgot_username.getText();
        pass = ForgotPassword1.getText();
        pass_check = ForgotPassword2.getText();
        city = Forgot_City.getText();
        hero = Forgot_hero.getText();
        String answer = "";
        answer = ForgetPassword.resetPassword(user ,city,hero, pass , pass_check );
        if(answer.equals("strong")) {
            Forgot_label.setText("your password is changed");
            return;
        }
        if(answer.equals("weak")) {
            Forgot_label.setText("your password is weak");
            return;
        }
        else {
            Forgot_label.setText(answer);
            return;
        }

    }
    public void loginrun(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("tweet.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }
    public void darkmood(javafx.event.ActionEvent event) throws IOException {
        mood ++;
        if(mood==3)
            mood=1;
        if(mood==1) {
            Parent root = FXMLLoader.load(getClass().getResource("tweet.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            String css = this.getClass().getResource("timelineStyle.css").toExternalForm();
            scene.getStylesheets().add(css);
            stage.setScene(scene);
            timeline_username.setText(user);
            stage.show();
        }
        else
        {
            Parent root = FXMLLoader.load(getClass().getResource("tweet.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            String css = this.getClass().getResource("timelineStyleDark.css").toExternalForm();
            scene.getStylesheets().add(css);
            stage.setScene(scene);
            timeline_username.setText(user);
            stage.show();
        }
    }

    public void logout_time(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }

    public void MainPage(javafx.event.ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
    }

    //ChatPage
    public void treeLineButtonClicked(javafx.event.ActionEvent event) throws IOException {
        System.out.println("tree Line...");
        Parent root = FXMLLoader.load(getClass().getResource("TreeLine.fxml"));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("timelineStyleDark.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
        //Main.changeMenu("TreeLine",new Stage());
    }

    public void startChatButtonClicked(javafx.event.ActionEvent event) throws IOException {
        System.out.println("Chat Page...");
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("ChatPage.fxml")));
        stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        String css = this.getClass().getResource("LoginStyle.css").toExternalForm();
        scene.getStylesheets().add(css);
        stage.setScene(scene);
        stage.show();
        // Main.changeMenu("ChatPage",new Stage());
    }

    @FXML
    public ChoiceBox<String> AccountType=new ChoiceBox<>();
    private String[]Accounttype={"Normal","Business"};

    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
       AccountType.getItems().addAll(Accounttype);
       AccountType.setOnAction(this::getChoise);

    }
    public void getChoise(ActionEvent event){
        String myChoise=AccountType.getValue();
        if (myChoise.equalsIgnoreCase("Normal")) {
            modle.NormalAccount.processCreateNormalAccounts(user);
            return;
        } else if (myChoise.equalsIgnoreCase("Business")) {
            modle. BusinessAccount.processCreateBusinessAccounts(user);
            return;
        }
    }

}
